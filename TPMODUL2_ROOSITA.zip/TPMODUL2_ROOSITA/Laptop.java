public class Laptop {
    public void informasi()
{
    System.out.println("Laptop ini memiliki drive tipe Seagate dengan ra, sebesar 8 GB dan processor secepat 2.40 Ghz. Selain itu laptop ini juga memiliki Webcam");
}
    public void bukaGame(String nama_game)
    {
        System.out.println("Laptop berhasil membuka game Dota 2");

    }
    public void kirimEmail(int email)
    {
        System.out.println("Laptop berhasil mengirim Email ke ocit@gmail.com");
    }
    public void kirimEmail(String email1, String email2)
    {
        System.out.println("Handphone berhasil mengirim Email ke ocit@gmail.com dan ke romi@gmail.com");
    }
}
