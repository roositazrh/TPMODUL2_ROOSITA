public class MainApp {
    public static void main(String[] args)
    {
        System.out.println("Class Handphone");
        Handphone hp = new Handphone();
        Handphone1.informasi();
        Handphone1.telfon();
        Handphone1.kirimSMS();
        Handphone1.kirimSMS();
        System.out.println("");

        System.out.println("Class Laptop");
        Laptop lpt = new Laptop();
        lpt.informasi();
        lpt.telfon();
        lpt.kirimSMS();
        lpt.kirimSMS();
        System.out.println("");
    }
}
