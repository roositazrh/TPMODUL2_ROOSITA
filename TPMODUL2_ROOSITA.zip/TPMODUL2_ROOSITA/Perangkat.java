public class Perangkat {
    public void informasi(String drive, int ram, float processor)
{
    System.out.println("Perankat tidak diketahui memiliki drive tipe data dengan ram sebesar 2 GB dan processor secepat 1.00 Ghz");
}
}
